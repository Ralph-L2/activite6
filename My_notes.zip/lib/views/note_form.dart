import 'package:flutter/material.dart';

import '../modele/note.dart';
import '../services/database_manager.dart';

class NoteForm extends StatefulWidget {
  final Note? note;

  const NoteForm({
    super.key,
    this.note,
  });

  @override
  State<NoteForm> createState() => _NoteFormState();
}

class _NoteFormState extends State<NoteForm> {
  final TextEditingController _titreController = TextEditingController();

  final TextEditingController _contenuController = TextEditingController();

  final DatabaseManager _databaseManager = DatabaseManager.instance;

  bool get _modeModification => widget.note != null;

  @override
  void initState() {
    super.initState();

    if (widget.note != null) {
      _titreController.text = widget.note!.titre;
      _contenuController.text = widget.note!.contenu;
    }
  }

  Future<void> _sauvegarder() async {
    final titre = _titreController.text.trim();
    final contenu = _contenuController.text.trim();

    if (titre.isEmpty || contenu.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Veuillez remplir tous les champs.',
          ),
        ),
      );
      return;
    }

    if (_modeModification) {
      final noteModifiee = Note.avecId(
        id: widget.note!.id,
        titre: titre,
        contenu: contenu,
      );

      await _databaseManager.updateNote(noteModifiee);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Note modifiée avec succès.'),
        ),
      );
    } else {
      final nouvelleNote = Note(
        titre: titre,
        contenu: contenu,
      );

      await _databaseManager.insertNote(nouvelleNote);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Note enregistrée avec succès.'),
        ),
      );
    }

    if (!mounted) return;

    Navigator.pop(context, true);
  }

  @override
  void dispose() {
    _titreController.dispose();
    _contenuController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _modeModification ? 'Modifier la note' : 'Nouvelle note',
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titreController,
              decoration: InputDecoration(
                labelText: 'Titre',
                prefixIcon: const Icon(Icons.title),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 18),
            TextField(
              controller: _contenuController,
              maxLines: 10,
              decoration: InputDecoration(
                labelText: 'Contenu',
                alignLabelWithHint: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _sauvegarder,
              icon: Icon(
                _modeModification ? Icons.edit : Icons.save,
              ),
              label: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 14,
                ),
                child: Text(
                  _modeModification
                      ? 'Enregistrer les modifications'
                      : 'Enregistrer la note',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(
                  vertical: 12,
                ),
                child: Text('Annuler'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
