import 'package:flutter/material.dart';

import '../modele/note.dart';
import '../services/database_manager.dart';
import 'note_form.dart';

class NotesInterface extends StatefulWidget {
  const NotesInterface({super.key});

  @override
  State<NotesInterface> createState() => _NotesInterfaceState();
}

class _NotesInterfaceState extends State<NotesInterface> {
  final DatabaseManager _databaseManager = DatabaseManager.instance;

  List<Note> _notes = [];

  @override
  void initState() {
    super.initState();
    _chargerNotes();
  }

  Future<void> _chargerNotes() async {
    final notes = await _databaseManager.getAllNotes();

    if (!mounted) return;

    setState(() {
      _notes = notes;
    });
  }

  Future<void> _ajouterNote() async {
    final resultat = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const NoteForm(),
      ),
    );

    if (resultat == true) {
      await _chargerNotes();
    }
  }

  Future<void> _modifierNote(Note note) async {
    final resultat = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NoteForm(note: note),
      ),
    );

    if (resultat == true) {
      await _chargerNotes();
    }
  }

  Future<void> _supprimerNote(Note note) async {
    final confirmation = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Supprimer la note'),
          content: Text(
            'Voulez-vous vraiment supprimer la note '
            '"${note.titre}" ?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('Annuler'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('Supprimer'),
            ),
          ],
        );
      },
    );

    if (confirmation == true && note.id != null) {
      await _databaseManager.deleteNote(note.id!);
      await _chargerNotes();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Note supprimée avec succès.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes notes'),
        centerTitle: true,
      ),
      body: _notes.isEmpty
          ? const Center(
              child: Text(
                'Aucune note enregistrée.',
                style: TextStyle(fontSize: 17),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _notes.length,
              itemBuilder: (context, index) {
                final note = _notes[index];

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    onTap: () {
                      _modifierNote(note);
                    },
                    leading: const CircleAvatar(
                      child: Icon(Icons.note),
                    ),
                    title: Text(
                      note.titre,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      note.contenu,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        _supprimerNote(note);
                      },
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _ajouterNote,
        icon: const Icon(Icons.add),
        label: const Text('Nouvelle note'),
      ),
    );
  }
}
