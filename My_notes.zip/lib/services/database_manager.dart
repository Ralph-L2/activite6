import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../modele/note.dart';

class DatabaseManager {
  static final DatabaseManager instance = DatabaseManager._internal();

  static Database? _database;

  DatabaseManager._internal();

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasesPath = await getDatabasesPath();
    final path = join(databasesPath, 'my_notes.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titre TEXT NOT NULL,
            contenu TEXT NOT NULL
          )
        ''');
      },
    );
  }

  Future<List<Note>> getAllNotes() async {
    final db = await database;

    final result = await db.query(
      'notes',
      orderBy: 'id DESC',
    );

    return result.map((map) {
      return Note.fromMap(map);
    }).toList();
  }

  Future<int> insertNote(Note note) async {
    final db = await database;

    return await db.insert(
      'notes',
      note.toMap(),
    );
  }

  Future<int> updateNote(Note note) async {
    final db = await database;

    return await db.update(
      'notes',
      note.toMap(),
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  Future<int> deleteNote(int id) async {
    final db = await database;

    return await db.delete(
      'notes',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
